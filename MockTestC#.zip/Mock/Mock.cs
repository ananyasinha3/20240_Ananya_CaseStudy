﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mock
{
    class Publication
    {
       private string title;
       private float price;
        public Publication(string titl,float price)
        {
            Title = title;
            Price = price;
        }
        public string Title { get; set; }
        public float Price { get; set; }
        public virtual string Display()
        {
            return $"The title is {Title} and the price is {Price}";
            
        }          

    }
    class Book:Publication
    {
       private int pageCount;
       private string author;
        public Book(string title,float price,int pc,string auth):base(title,price)
        {
            PageCount = pc;
            Author = auth;
        }
        public int PageCount { get; set; }
        public string Author { get; set; }
        public override string Display()
        {
           return $"The page count of {Title} is {PageCount} and the Author is {Author}.";
            
        }

    }
    

    class Video:Publication
    {
        private int duration;
        public Video(string title, float price, int dur) : base(title, price)
        {
            Duration = dur;
           
        }
        public int Duration { get; set; }
      
        public override string Display()
        {
            return $"The duration of {Title} is {Duration} minutes.";
        }
    }

    class Test
    {
        public static void Main()
        {
            Book b = new Book("Alchemist",234,322,"Paulo Coelho");
            Console.WriteLine(b.Display());

            Video v = new Video("Matrix",200,180);
            Console.WriteLine(v.Display());

        }

    }
   
}
