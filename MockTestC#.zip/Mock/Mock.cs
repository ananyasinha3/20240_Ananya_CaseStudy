﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mock
{
    class Publication
    {
        string title;
        float price;
     public virtual void Get()
        {
            Console.WriteLine("Enter the title:");
            title= Console.ReadLine();
            Console.WriteLine("Enter the price:");
            price=int.Parse(Console.ReadLine());
        }
        public virtual string Display()
        {
            return $"The title is {title} and the price is {price}";
            
        }          

    }
    class Book:Publication
    {
       int pageCount;
       string Author;
        public override void Get()
        {
            Console.WriteLine("Enter the Page Count of Book:");
            pageCount = int.Parse(Console.ReadLine());            
            Console.WriteLine("Enter the Author name of Book:");
            Author = Console.ReadLine();

        }
        public override string Display()
        {
           return $"The page count is {pageCount} and the Author is {Author}";
            
        }

    }
    

    class Video:Publication
    {
        int duration;
        public override void Get()
        {
            Console.WriteLine("Enter the duration of the video:");
            duration = int.Parse(Console.ReadLine());

        }
        public override string Display()
        {
            return $"The duration is {duration} minutes.";
        }
    }

    class Test
    {
        public static void Main()
        {
            Publication p = new Publication();
            p.Get();
            Console.WriteLine(p.Display());

            Book b = new Book();
            b.Get();
            Console.WriteLine(b.Display());

            Video v = new Video();
            v.Get();
            Console.WriteLine(v.Display());

        }

    }
   
}
