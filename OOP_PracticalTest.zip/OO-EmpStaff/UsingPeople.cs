﻿using System;

namespace OO_EmpStaff
{
    /// <summary>
    /// class UsingPeople creates instances of the classes TechnicalEmpoyee and Staff.
    /// The ToString method is used to retrieve the given employee's id and name and the calculateSalary method is used to calculate the given emloyee's salary.
    /// </summary>
    class UsingPeople
    {

        public static void Main(string[] args)
        {
            
            Employee techEmp = new TechnicalEmployee("1234", "Veronica", new string[] { "C", "C++", "Java" }, -20000);
            Console.WriteLine(techEmp.ToString());
            Console.WriteLine(techEmp.calculateSalary());

            Employee staff = new Staff("4567", "Ashley", "Security", 13000);
            Console.WriteLine(staff.ToString());
            Console.WriteLine(staff.calculateSalary());
           

        }
    }
}
