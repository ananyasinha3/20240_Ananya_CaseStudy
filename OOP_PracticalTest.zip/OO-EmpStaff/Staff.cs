﻿using System;

namespace OO_EmpStaff
{
    /// <summary>
    /// class Staff is inherited from base class Employee.
    /// </summary>
    class Staff : Employee
    {
        public string Title;

        //constructor will read employee id,name and basic pay from base class
        public Staff(string Empid, string Empname, string title, int BasicPay) : base(Empid, Empname, BasicPay)        
        {
            Title = title;
        }

        /// <summary>
        /// calculateSalary returns the staff's salary as per the calculation shown below.
        /// salary = basicPay + 18%(basicPay)
        /// </summary>
        public override double calculateSalary()
        {
            double salary = Math.Round(1.18 * BasicPay);
            return salary;
        }

        /// <summary>
        /// The ToString method returns the employee name and employee id.
        /// </summary>
        public override string ToString()
        {
            return $"The employee id of {empname} is {empid}.";
        }

    }
}
