﻿using System;

namespace OO_EmpStaff
{
    public abstract class Employee
    {
        public string empid;
        public string empname;
        private string address;
        private double basicpay;
        public Employee(string empID,string empName,double basicPay)
        {
            empid = empID;
            empname = empName;
            BasicPay = basicPay;
            try
            {
                if (BasicPay < 0)
                {
                    throw new InvalidInput("Basic pay is invalid. It cannot be negative.");
                }
            }
            catch (InvalidInput)
            {
               
            }
     
        }
        public string Address { get; set; }
        public double BasicPay { get; set; }
        public abstract double calculateSalary();
        

    }
    
   
   
}
