﻿using System;

namespace OO_EmpStaff
{
    /// <summary>
    /// class TechnicalEmployee is inherited from base class Employee.
    /// </summary>
    class TechnicalEmployee : Employee
    {
        string[] skills;

        //constructor will read employee id,name and basic pay from base class
        public TechnicalEmployee(string Empid, string Empname, string[] skill, int BasicPay) : base(Empid, Empname, BasicPay)
        {
            this.skills = skill;
        }

        /// <summary>
        /// calculateSalary returns the technical employee's salary as per the calculation shown below.
        /// salary = basicPay + 12%(basicPay)
        /// </summary>
        public override double calculateSalary()
        {
            double salary = Math.Round(1.12 * BasicPay);
            return salary;
        }

        /// <summary>
        /// The ToString method returns the employee name and employee id.
        /// </summary>
        public override string ToString()
        {
            return $"The employee id of {empname} is {empid}.";
        }
    }
}
