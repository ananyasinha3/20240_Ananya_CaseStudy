﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OO_EmpStaff
{
    /// <summary>
    /// Exception when the input given by user is invalid.
    /// </summary>
    class InvalidInput:Exception
    {
        public InvalidInput(string errorMessage):base(errorMessage)
        {

        }

    }
}
